--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: iniciar_aventura(character varying, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.iniciar_aventura(p_jogador_id character varying, p_aventura_nome character varying) RETURNS TABLE(paragrafo_id integer, texto_paragrafo text, opcoes_json jsonb, aventura_ref character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE v_paragrafo_inicial INTEGER;
BEGIN
    SELECT paragrafo_inicial INTO v_paragrafo_inicial FROM aventuras_catalogo WHERE nome = p_aventura_nome;
    
    INSERT INTO aventuras_progresso (jogador_id, aventura_nome, paragrafo_atual, paragrafos_visitados)
    VALUES (p_jogador_id, p_aventura_nome, v_paragrafo_inicial, jsonb_build_array(v_paragrafo_inicial))
    ON CONFLICT (jogador_id, aventura_nome) 
    DO UPDATE SET 
        paragrafo_atual = v_paragrafo_inicial, 
        paragrafos_visitados = jsonb_build_array(v_paragrafo_inicial), 
        ultima_acao = NOW(), 
        finalizado = false;

    RETURN QUERY SELECT par.numero, par.texto, par.opcoes, p_aventura_nome 
    FROM aventuras_paragrafos par 
    WHERE par.aventura_nome = p_aventura_nome AND par.numero = v_paragrafo_inicial;
END;
$$;


--
-- Name: ir_paragrafo(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ir_paragrafo(p_jogador_id character varying, p_aventura_nome character varying, p_numero_paragrafo integer) RETURNS TABLE(paragrafo_id integer, texto_paragrafo text, opcoes_json jsonb, aventura_ref character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE aventuras_progresso 
    SET paragrafo_atual = p_numero_paragrafo, 
        paragrafos_visitados = paragrafos_visitados || jsonb_build_array(p_numero_paragrafo), 
        ultima_acao = NOW()
    WHERE jogador_id = p_jogador_id AND aventura_nome = p_aventura_nome;

    RETURN QUERY SELECT par.numero, par.texto, par.opcoes, p_aventura_nome 
    FROM aventuras_paragrafos par 
    WHERE par.aventura_nome = p_aventura_nome AND par.numero = p_numero_paragrafo;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aliados_e_npcs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aliados_e_npcs (
    id integer NOT NULL,
    nome character varying(50),
    raca_classe character varying(50),
    hp_atual integer,
    tendencia character varying(20),
    notas_personalidade text
);


--
-- Name: aliados_e_npcs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aliados_e_npcs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aliados_e_npcs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aliados_e_npcs_id_seq OWNED BY public.aliados_e_npcs.id;


--
-- Name: aventura_cidadela; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aventura_cidadela (
    cod_sala character varying NOT NULL,
    nome_sala character varying,
    descricao_visual text,
    segredos_mestre text,
    conexoes json
);


--
-- Name: aventuras_catalogo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aventuras_catalogo (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    titulo character varying(200) NOT NULL,
    descricao text,
    autor character varying(100),
    dificuldade character varying(20),
    nivel_recomendado character varying(20),
    paragrafo_inicial integer DEFAULT 1,
    total_paragrafos integer,
    tempo_estimado_minutos integer,
    ativa boolean DEFAULT true,
    criado_em timestamp without time zone DEFAULT now()
);


--
-- Name: aventuras_catalogo_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aventuras_catalogo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aventuras_catalogo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aventuras_catalogo_id_seq OWNED BY public.aventuras_catalogo.id;


--
-- Name: aventuras_inventario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aventuras_inventario (
    id integer NOT NULL,
    progresso_id integer,
    item_nome character varying(100) NOT NULL,
    item_tipo character varying(50),
    quantidade integer DEFAULT 1,
    descricao text,
    paragrafo_obtido integer,
    usado boolean DEFAULT false
);


--
-- Name: aventuras_inventario_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aventuras_inventario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aventuras_inventario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aventuras_inventario_id_seq OWNED BY public.aventuras_inventario.id;


--
-- Name: aventuras_paragrafos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aventuras_paragrafos (
    id integer NOT NULL,
    aventura_nome character varying(100),
    numero integer NOT NULL,
    texto text NOT NULL,
    opcoes jsonb DEFAULT '[]'::jsonb,
    tipo character varying(20) DEFAULT 'normal'::character varying,
    requer_teste boolean DEFAULT false,
    teste_atributo character varying(10),
    teste_dificuldade integer,
    sucesso_paragrafo integer,
    falha_paragrafo integer,
    imagem_url text
);


--
-- Name: aventuras_paragrafos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aventuras_paragrafos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aventuras_paragrafos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aventuras_paragrafos_id_seq OWNED BY public.aventuras_paragrafos.id;


--
-- Name: aventuras_progresso; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aventuras_progresso (
    id integer NOT NULL,
    jogador_id character varying(50) NOT NULL,
    aventura_nome character varying(100),
    paragrafo_atual integer NOT NULL,
    paragrafos_visitados jsonb DEFAULT '[]'::jsonb,
    itens_coletados jsonb DEFAULT '[]'::jsonb,
    decisoes jsonb DEFAULT '{}'::jsonb,
    hp_atual integer,
    hp_maximo integer,
    energia integer DEFAULT 10,
    ouro integer DEFAULT 0,
    iniciado_em timestamp without time zone DEFAULT now(),
    ultima_acao timestamp without time zone DEFAULT now(),
    finalizado boolean DEFAULT false,
    final_alcancado character varying(50)
);


--
-- Name: aventuras_progresso_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aventuras_progresso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aventuras_progresso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aventuras_progresso_id_seq OWNED BY public.aventuras_progresso.id;


--
-- Name: aventuras_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aventuras_stats (
    id integer NOT NULL,
    aventura_nome character varying(100),
    total_inicios integer DEFAULT 0,
    total_conclusoes integer DEFAULT 0,
    total_mortes integer DEFAULT 0,
    tempo_medio_minutos integer,
    paragrafo_mais_visitado integer,
    escolha_mais_comum jsonb,
    atualizado_em timestamp without time zone DEFAULT now()
);


--
-- Name: aventuras_stats_globais; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.aventuras_stats_globais AS
 SELECT count(DISTINCT jogador_id) AS total_jogadores,
    count(*) AS total_aventuras_iniciadas,
    sum(
        CASE
            WHEN finalizado THEN 1
            ELSE 0
        END) AS total_conclusoes,
    round(avg((EXTRACT(epoch FROM (ultima_acao - iniciado_em)) / (60)::numeric)), 0) AS tempo_medio_minutos
   FROM public.aventuras_progresso;


--
-- Name: aventuras_stats_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aventuras_stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aventuras_stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aventuras_stats_id_seq OWNED BY public.aventuras_stats.id;


--
-- Name: bestiario_cidadela; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bestiario_cidadela (
    nome character varying NOT NULL,
    ca integer,
    hp_max integer,
    ataque character varying,
    dano character varying,
    ouro_recompensa integer,
    xp_recompensa integer
);


--
-- Name: campanhas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campanhas (
    grupo_id character varying NOT NULL,
    cena_atual character varying,
    estado_salas json,
    ultimo_evento json,
    momento character varying,
    tensao integer,
    turno_atual integer
);


--
-- Name: campanhas_cenas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.campanhas_cenas (
    id integer NOT NULL,
    aventura_ref character varying(100) NOT NULL,
    cena_id character varying(50) NOT NULL,
    nome_local character varying(100) NOT NULL,
    descricao_narrativa text NOT NULL,
    regras_da_sala text NOT NULL,
    conexoes jsonb DEFAULT '[]'::jsonb
);


--
-- Name: campanhas_cenas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.campanhas_cenas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: campanhas_cenas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.campanhas_cenas_id_seq OWNED BY public.campanhas_cenas.id;


--
-- Name: cenas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cenas (
    cod_sala character varying NOT NULL,
    nome_sala character varying,
    descricao_visual text,
    conexoes json
);


--
-- Name: criacao_ficha; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.criacao_ficha (
    telefone character varying(50) NOT NULL,
    etapa character varying(50) NOT NULL,
    dados_temp jsonb DEFAULT '{}'::jsonb,
    criado_em timestamp without time zone DEFAULT now(),
    atualizado_em timestamp without time zone DEFAULT now()
);


--
-- Name: diario_thorak; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diario_thorak (
    id integer NOT NULL,
    data_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    evento text,
    sala_atual character varying(50),
    hp_restante integer
);


--
-- Name: diario_thorak_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.diario_thorak_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: diario_thorak_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.diario_thorak_id_seq OWNED BY public.diario_thorak.id;


--
-- Name: documentos_aventura; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documentos_aventura (
    id integer NOT NULL,
    nome_item character varying(100),
    conteudo_texto text,
    sala_onde_encontra character varying(50)
);


--
-- Name: documentos_aventura_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documentos_aventura_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documentos_aventura_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documentos_aventura_id_seq OWNED BY public.documentos_aventura.id;


--
-- Name: encontros_salas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.encontros_salas (
    id integer NOT NULL,
    cod_sala character varying,
    nome_inimigo character varying,
    quantidade integer,
    condicao_aparecimento character varying,
    ativo boolean
);


--
-- Name: encontros_salas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.encontros_salas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: encontros_salas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.encontros_salas_id_seq OWNED BY public.encontros_salas.id;


--
-- Name: grimorio_cidadela; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grimorio_cidadela (
    id integer NOT NULL,
    nome_magia character varying(50),
    nivel integer,
    alcance character varying(30),
    efeito text
);


--
-- Name: grimorio_cidadela_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grimorio_cidadela_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grimorio_cidadela_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grimorio_cidadela_id_seq OWNED BY public.grimorio_cidadela.id;


--
-- Name: itens_magicos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.itens_magicos (
    id integer NOT NULL,
    nome character varying(100),
    propriedades text,
    valor_ouro integer
);


--
-- Name: itens_magicos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.itens_magicos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: itens_magicos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.itens_magicos_id_seq OWNED BY public.itens_magicos.id;


--
-- Name: jogadores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jogadores (
    telefone character varying NOT NULL,
    nome character varying,
    classe character varying,
    raca character varying,
    background character varying,
    nivel integer,
    xp integer,
    hp integer,
    hp_atual integer,
    hp_maximo integer,
    str integer,
    dex integer,
    con integer,
    "int" integer,
    wis integer,
    cha integer,
    mod_str integer,
    mod_dex integer,
    mod_con integer,
    mod_int integer,
    mod_wis integer,
    mod_cha integer,
    modificador_ataque integer,
    modificador_magia integer,
    modificador_teste integer,
    modificador_defesa integer,
    proficiencia integer,
    dano_dado character varying,
    mod_dano integer,
    slots_magia integer,
    slots_magia_max integer,
    magias_conhecidas json,
    gold integer,
    inventario text,
    respawns_usados integer,
    descanso_curto_disponivel boolean
);


--
-- Name: logs_navegacao; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logs_navegacao (
    id integer NOT NULL,
    telefone character varying(20),
    sala_origem character varying(50),
    texto_digitado text,
    sala_destino character varying(50),
    sucesso boolean,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: logs_navegacao_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.logs_navegacao_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logs_navegacao_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.logs_navegacao_id_seq OWNED BY public.logs_navegacao.id;


--
-- Name: masmorra_cenas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.masmorra_cenas (
    id integer NOT NULL,
    sala_id character varying(50),
    nome_sala character varying(100),
    descricao text,
    inimigos text,
    saidas text
);


--
-- Name: masmorra_cenas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.masmorra_cenas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: masmorra_cenas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.masmorra_cenas_id_seq OWNED BY public.masmorra_cenas.id;


--
-- Name: monster_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monster_templates (
    id integer NOT NULL,
    nome character varying(100),
    hp_base integer,
    ca integer,
    ataque_bonus integer,
    dano_dice character varying(20),
    xp integer
);


--
-- Name: monster_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.monster_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: monster_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.monster_templates_id_seq OWNED BY public.monster_templates.id;


--
-- Name: regras_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.regras_cache (
    nome character varying(200) NOT NULL,
    openai_file_id character varying(100) NOT NULL,
    atualizado_em timestamp without time zone DEFAULT now()
);


--
-- Name: turnos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.turnos (
    grupo_id character varying(100) NOT NULL,
    indice integer DEFAULT 0
);


--
-- Name: aliados_e_npcs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aliados_e_npcs ALTER COLUMN id SET DEFAULT nextval('public.aliados_e_npcs_id_seq'::regclass);


--
-- Name: aventuras_catalogo id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_catalogo ALTER COLUMN id SET DEFAULT nextval('public.aventuras_catalogo_id_seq'::regclass);


--
-- Name: aventuras_inventario id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_inventario ALTER COLUMN id SET DEFAULT nextval('public.aventuras_inventario_id_seq'::regclass);


--
-- Name: aventuras_paragrafos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_paragrafos ALTER COLUMN id SET DEFAULT nextval('public.aventuras_paragrafos_id_seq'::regclass);


--
-- Name: aventuras_progresso id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_progresso ALTER COLUMN id SET DEFAULT nextval('public.aventuras_progresso_id_seq'::regclass);


--
-- Name: aventuras_stats id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_stats ALTER COLUMN id SET DEFAULT nextval('public.aventuras_stats_id_seq'::regclass);


--
-- Name: campanhas_cenas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campanhas_cenas ALTER COLUMN id SET DEFAULT nextval('public.campanhas_cenas_id_seq'::regclass);


--
-- Name: diario_thorak id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diario_thorak ALTER COLUMN id SET DEFAULT nextval('public.diario_thorak_id_seq'::regclass);


--
-- Name: documentos_aventura id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_aventura ALTER COLUMN id SET DEFAULT nextval('public.documentos_aventura_id_seq'::regclass);


--
-- Name: encontros_salas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encontros_salas ALTER COLUMN id SET DEFAULT nextval('public.encontros_salas_id_seq'::regclass);


--
-- Name: grimorio_cidadela id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grimorio_cidadela ALTER COLUMN id SET DEFAULT nextval('public.grimorio_cidadela_id_seq'::regclass);


--
-- Name: itens_magicos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.itens_magicos ALTER COLUMN id SET DEFAULT nextval('public.itens_magicos_id_seq'::regclass);


--
-- Name: logs_navegacao id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs_navegacao ALTER COLUMN id SET DEFAULT nextval('public.logs_navegacao_id_seq'::regclass);


--
-- Name: masmorra_cenas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.masmorra_cenas ALTER COLUMN id SET DEFAULT nextval('public.masmorra_cenas_id_seq'::regclass);


--
-- Name: monster_templates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monster_templates ALTER COLUMN id SET DEFAULT nextval('public.monster_templates_id_seq'::regclass);


--
-- Data for Name: aliados_e_npcs; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.aliados_e_npcs VALUES (1, 'Meepo', 'Kobold', 2, 'Leal e Neutro', 'Obcecado por dragões. Chora com facilidade. Quer ser amigo de quem o ajudar a achar Calcryx.');
INSERT INTO public.aliados_e_npcs VALUES (2, 'Erky Timbers', 'Gnomo Clérigo', 8, 'Bom e Neutro', 'Prisioneiro dos Goblins (Área 18/34 dependendo da versão). Pode curar o Thorak se for libertado.');
INSERT INTO public.aliados_e_npcs VALUES (3, 'Sharwyn Hucrele', 'Humana Maga', 7, 'Suplantada (Mal)', 'Filha de Kerowyn. Foi transformada em serva da árvore. Possui uma varinha de mísseis mágicos.');


--
-- Data for Name: aventura_cidadela; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.aventura_cidadela VALUES ('carvalhal', 'Vila de Carvalhal', 'A Vila de Carvalhal pulsa com uma tensão silenciosa. Aldeões olham desconfiados através de janelas de madeira húmida, enquanto a fumaça das chaminés se mistura com a névoa perpétua. A Taverna do Velho Javali é o único lugar que parece oferecer algum calor real.', '', '{"norte": "estrada_velha"}');
INSERT INTO public.aventura_cidadela VALUES ('estrada_velha', 'Estrada Velha', 'Uma trilha desolada e esquecida. Árvores retorcidas de galhos secos como garras observam o seu avanço. O vento aqui não canta, ele apenas sibila entre os troncos podres, cheirando a abandono e folhas mortas.', '', '{"sul": "carvalhal", "norte": "ravina_escura"}');
INSERT INTO public.aventura_cidadela VALUES ('ravina_escura', 'Área 0: Ravina', 'A terra abre-se numa fenda monumental, como se o mundo tivesse sido partido ao meio. Uma corda grossa, ancorada a um pilar de pedra rachada, desce rumo às profundezas onde a luz do sol não ousa entrar.', '', '{"sul": "estrada_velha", "descer": "sala_01"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_01', 'Área 1: Parapeito', 'Você aterra num parapeito estreito. O ar é gélido, cheirando a pó e pedra molhada. Nas sombras, o som de garras arranhando a rocha ecoa suavemente, anunciando que você não está sozinho.', '', '{"subir": "ravina_escura", "oeste": "sala_02"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_02', 'Área 2: Escadas Sinuosas', 'Uma escadaria de pedra em zigue-zague desce ainda mais para a escuridão. Os degraus estão irregulares e perigosos, cobertos por um musgo escorregadio e poças de água negra.', '', '{"leste": "sala_01", "baixo": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_03', 'Área 3: Pátio em Ruínas', 'O pátio de um antigo castelo que se afundou na terra. Paredes de granito destroçadas formam um anel ao redor de escombros. Estátuas sem cabeça de heróis do passado permanecem como sentinelas tristes no escuro.', '', '{"cima": "sala_02", "oeste": "sala_04", "norte": "sala_07"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_04', 'Área 4: Torre em Ruínas', 'Uma torre circular em ruínas. O teto desabou há séculos. No chão, quatro corpos de goblins em decomposição jazem espalhados; um deles está bizarramente empalado contra a parede oeste por uma lança ferrugenta.', '', '{"leste": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_05', 'Área 5: Corredor de Entrada', 'Uma pequena câmara secreta, abafada e com cheiro a ar preso há séculos. Teias de aranha grossas como cordas pendem do teto, escondendo cantos obscuros.', '', '{"norte": "sala_07"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_06', 'Área 6: Antessala Velha', 'Uma antessala fria com portas de pedra pesada. O silêncio aqui é perturbador, quebrado apenas pelo som da sua própria respiração e pelo gotejar distante de água.', '', '{"leste": "sala_07"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_07', 'Área 7: Galeria das Estátuas', 'A Galeria das Estátuas. Um longo corredor flanqueado por colunas esculpidas com a forma de dragões em voo. O chão está coberto por uma poeira espessa, ocultando perigos antigos.', '', '{"sul": "sala_03", "leste": "sala_21", "oeste": "sala_06", "norte": "sala_08"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_08', 'Área 8: Sala de Pressão', 'O corredor afunila. Há manchas escuras no chão de pedra que lembram sangue seco. Uma placa de pressão ligeiramente elevada no centro da sala sugere uma armadilha mecânica adormecida.', '', '{"sul": "sala_07", "norte": "sala_09"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_09', 'Área 9: Sala da Serpente', 'A Câmara da Serpente. Uma porta de pedra maciça bloqueia o caminho, entalhada com o formato de um dragão enrolado. Há um enigma dracónico desgastado gravado na base da porta.', '', '{"sul": "sala_08", "leste": "sala_10"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_10', 'Área 10: Corredor Estrito', 'O Corredor da Guarda de Honra. Nichos nas paredes contêm armaduras enferrujadas e vazias, de pé em posição de sentido. Elas parecem observar quem quer que passe por ali.', '', '{"oeste": "sala_09", "norte": "sala_12"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_11', 'Área 11: Câmara Secundária', 'Uma câmara secundária esquecida. Caixotes apodrecidos e barris desfeitos em lascas espalham-se pelo chão. O ar aqui tem o gosto amargo de bolor.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_12', 'Área 12: Tumba de Honorável', 'A Tumba do Sacerdote Dragão. Uma câmara silenciosa com um sarcófago de mármore liso no centro. Inscrições antigas em dracónico alertam severamente sobre a maldição dos violadores de tumbas.', '', '{"sul": "sala_10"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_13', 'Área 13: Câmara Secundária', 'Um corredor estreito e escuro. As paredes de granito estão cobertas de fungos cinzentos que parecem pulsar levemente quando você se aproxima.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_14', 'Área 14: Câmara Secundária', 'A câmara está parcialmente inundada com uma água escura e fétida, na altura dos tornozelos. O som de respingos ecoa, como se algo escorregadio nadasse nas sombras aquáticas.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_15', 'Área 15: Câmara Secundária', 'O posto de guarda Kobold. Fogueiras pequenas iluminam o rosto de criaturas reptilianas encolhidas em cantos, segurando lanças afiadas. O cheiro de carne queimada é forte.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_16', 'Área 16: Câmara Secundária', 'A Sala das Correntes. Uma cela reforçada onde enormes anéis de ferro pendem das paredes. O ar é incrivelmente frio aqui, e as paredes estão cobertas por uma fina camada de gelo.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_17', 'Área 17: Câmara Secundária', 'Um salão de transição longo. Peles de animais manchadas de sangue cobrem algumas passagens. O som de vozes esganiçadas e risadas cruéis reverbera mais adiante.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_18', 'Área 18: Câmara Secundária', 'Um cruzamento de corredores guardado por barricadas improvisadas com mesas quebradas. Kobolds nervosos patrulham a área, mantendo as armas em punho.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_19', 'Área 19: Câmara Secundária', 'Os quarteirões da tribo Kobold. Dezenas de ninhos de palha e tecido rasgado espalham-se pelo chão. O ruído constante de resmungos e dentes a ranger enche o ambiente.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_20', 'Área 20: Câmara Secundária', 'A antessala real. Cortinas rasgadas de veludo vermelho tentam, sem sucesso, dar um ar de nobreza a esta caverna fria.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_21', 'Área 21: Trono Kobold', 'O grande salão do trono. A líder kobold, Yusdrayl, majestosa e ameaçadora, governa o seu clã sentada num trono construído com blocos de altar roubados e ossos polidos.', '', '{"oeste": "sala_07", "norte": "sala_26"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_22', 'Área 22: Câmara Secundária', 'A antiga prisão. As grades de ferro estão tortas, algumas arrancadas das dobradiças. Restos de esqueletos humanoides jazem esquecidos nas celas mais escuras.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_23', 'Área 23: Câmara Secundária', 'Um santuário menor desconsagrado. O altar de pedra foi vandalizado com sangue goblin, e símbolos de crueldade foram pintados sobre os relevos sagrados originais.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_24', 'Área 24: Câmara Secundária', 'Um laboratório alquímico destruído. Vidros quebrados, cinzas e manchas químicas coloridas decoram o chão. Um odor metálico irrita a garganta.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_25', 'Área 25: Câmara Secundária', 'A antiga armaria. Prateleiras de madeira podre alinham as paredes. Quase tudo de valor já foi saqueado, restando apenas lanças partidas e escudos rachados.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_26', 'Área 26: Fronteira Goblin', 'Uma fonte circular de pedra, completamente seca. No centro, a estátua de um dragão com a boca aberta serve de poleiro para estranhos morcegos sem olhos.', '', '{"sul": "sala_21", "norte": "sala_33"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_27', 'Área 27: Câmara Secundária', 'Uma sala de descanso em ruínas. Bancos de pedra estão virados e marcados por garras profundas. O chão é uma cama de poeira inexplorada.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_28', 'Área 28: Câmara Secundária', 'O Corredor das Gárgulas. Figuras monstruosas de pedra observam do alto das paredes. A sensação de estar sendo vigiado é angustiante.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_29', 'Área 29: Câmara Secundária', 'Um fosso seco corta o caminho. Uma tábua de madeira bamba e podre serve como única ponte para o lado goblin da cidadela.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_30', 'Área 30: Câmara Secundária', 'Um posto avançado Goblin. Ossos de pequenos animais formam decorações macabras penduradas no teto. O fedor de goblin não lavado é esmagador.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_31', 'Área 31: Câmara Secundária', 'Um corredor estreito e traiçoeiro. Existem frestas suspeitas nas paredes de pedra, um clássico indício de armadilhas com flechas prontas a disparar.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_32', 'Área 32: Câmara Secundária', 'A Câmara dos Espinhos. O chão cede para um buraco escuro cheio de lanças e galhos afiados. É preciso cuidado extremo para navegar por aqui.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_33', 'Área 33: Quartéis Goblin', 'O Quartel General Goblin. O cheiro é insuportável. Camas de palha imunda e lixo espalhado mostram que dezenas de goblins vivem, comem e lutam neste salão caótico.', '', '{"sul": "sala_26", "norte": "sala_41"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_34', 'Área 34: Câmara Secundária', 'A cozinha imunda dos goblins. Caldeirões fervem com carnes não identificáveis. O vapor engordurado mancha as paredes de preto.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_35', 'Área 35: Câmara Secundária', 'A despensa dos horrores. Barris quebrados e sacos roídos por ratos alinham as prateleiras. Pequenos vermes movem-se na penumbra.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_36', 'Área 36: Câmara Secundária', 'A prisão goblin. Cordas e correntes estão presas a argolas no chão. Marcas de desespero nas paredes mostram onde prisioneiros tentaram, em vão, escapar.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_37', 'Área 37: Câmara Secundária', 'A sala de troféus. Crânios de diversas criaturas, incluindo alguns anões e elfos, estão empalados em estacas. O ambiente exala brutalidade selvagem.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_38', 'Área 38: Câmara Secundária', 'O salão da guarda de elite. Goblins com armaduras mais limpas (ou menos sujas) montam guarda aqui. A disciplina entre eles é mantida pelo medo.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_39', 'Área 39: Câmara Secundária', 'Câmara de interrogatório. Ferramentas cruéis pendem das paredes. No centro, uma mesa de pedra está impregnada de escuridão e manchas inquietantes.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_40', 'Área 40: Câmara Secundária', 'O Santuário de Maglubiyet. Ídolos macabros de barro e sangue adornam a parede. Uma fumaça de incenso nauseabundo queima lentamente num braseiro enferrujado.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_41', 'Área 41: Trono de Durnn', 'O covil de Durnn, o cruel Chefe Goblin. Troféus de heróis caídos estão amontoados. No fundo da sala, um poço perfeitamente cilíndrico mergulha nas profundezas escuras da terra.', '', '{"sul": "sala_33", "baixo": "sala_42"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_42', 'Área 42: Pilares Enraizados', 'Você chega ao Nível do Bosque Inferior. O teto aqui é sustentado por pilares que parecem árvores petrificadas, envoltas em raízes cinzentas que parecem vivas e pulsantes.', '', '{"cima": "sala_41", "norte": "sala_43"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_43', 'Área 43: Corredor de Musgo', 'Um corredor coberto de fungos fosforescentes. A luz verde pálida ilumina esporos que dançam no ar frio, dando uma sensação de irrealidade ao ambiente.', '', '{"sul": "sala_42", "norte": "sala_49"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_44', 'Área 44: Câmara Secundária', 'A caverna dos insetos. O chão está coberto de exoesqueletos esmagados e terra remexida. Zumbidos graves podem ser ouvidos vindos de fissuras nas rochas.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_45', 'Área 45: Câmara Secundária', 'O início do Bosque das Sombras. Árvores retorcidas crescem na escuridão subterrânea sem precisar de sol, alimentando-se apenas da energia mágica do local.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_46', 'Área 46: Câmara Secundária', 'Um santuário engolido por vinhas espinhosas. Restos de uma divindade silvestre jazem quebrados sob uma cama de mato grosso e hostil.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_47', 'Área 47: Câmara Secundária', 'A Passagem Entrelaçada. Raízes grossas como troncos bloqueiam metade do caminho, forçando-o a espremer-se entre a casca áspera que parece sangrar seiva vermelha.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_48', 'Área 48: Câmara Secundária', 'A caverna do musgo gigante. Tapetes de musgo amarelo e púrpura cobrem tudo, macios como almofadas, mas exalam um gás com cheiro a podridão doce.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_49', 'Área 49: Jardim Crepuscular', 'O Jardim Crepuscular. Uma área agrícola bizarra. O solo foi arado, mas as plantas que aqui crescem são pálidas, venenosas e cheias de espinhos. Arbustos secos tremem sem vento.', '', '{"sul": "sala_43", "oeste": "sala_53", "norte": "sala_56"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_50', 'Área 50: Câmara Secundária', 'A estufa macabra. Parede de pedras desabadas formam um canto escuro onde mudas de plantas trepadeiras parecem esticar as folhas em direção ao calor do seu corpo.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_51', 'Área 51: Câmara Secundária', 'A biblioteca em ruínas de Belak. Pilhas de livros apodrecidos e pergaminhos esfarelados sobre rituais druídicos sombrios forram o chão úmido.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_52', 'Área 52: Câmara Secundária', 'Os aposentos espartanos do Druida. Uma cama de folhas secas, uma bacia de pedra com água estagnada e símbolos de pura obsessão rúnica desenhados nas paredes.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_53', 'Área 53: Lab de Belak', 'O laboratório botânico profano. Mesas de madeira vergadas sob o peso de frascos esguios, ervas trituradas e anotações frenéticas sobre enxertos de sangue e raízes vampíricas.', '', '{"leste": "sala_49"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_54', 'Área 54: Câmara Secundária', 'A Gruta Lamacenta. O chão transforma-se num pântano subterrâneo profundo e nojento. O coaxar baixo e gutural de anfíbios gigantes ressoa nas paredes da caverna.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_55', 'Área 55: Câmara Secundária', 'A Clareira Inferior. O ar aqui é sufocante e pesado com o cheiro de seiva mágica. O ambiente é tenso, como se o próprio chão estivesse a prender a respiração para o que está à frente.', '', '{"voltar": "sala_03"}');
INSERT INTO public.aventura_cidadela VALUES ('sala_56', 'Área 56: Árvore de Gulthias', 'O Coração do Mal. No centro da clareira final, ergue-se a colossal Árvore de Gulthias — uma abominação de madeira negra que bebe sangue em vez de água. Belak, o Proscrito, aguarda nas suas sombras.', '', '{"sul": "sala_49"}');


--
-- Data for Name: aventuras_catalogo; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.aventuras_catalogo VALUES (1, 'templo-do-terror', 'O Templo do Terror', 'Uma jornada épica para recuperar cinco artefatos dragões roubados pelo maligno Malbordus. Atravesse o Porto de Craggen, navegue pela Costa Selvagem e infiltre-se no sinistro Templo do Terror.', 'Ian Livingstone', 'dificil', '1-10', 1, 400, 120, true, '2026-02-18 21:38:03.647939');


--
-- Data for Name: aventuras_inventario; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: aventuras_paragrafos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.aventuras_paragrafos VALUES (1, 'templo-do-terror', 1, 'Para um homem velho, Yaztromo é surpreendentemente vivaz. Você atravessa Red River e os campos arados além, o logo chega ao limite de Port Blacksand. Yaztromo continua. Toma um caminho estreito em direção à escura muralha de árvores. Está escurecendo; raízes emaranhadas obstruem a passagem e tornam a caminhada muito cansativa. Você pergunta a Yaztromo por que ele parece tão despreocupado em relação à possibilidade de ser atacado pelos monstros da floresta. Ele ironiza e diz que sua magia é bem conhecida e respeitada por todas as criaturas numa área de muitas milhas - ninguém ousaria desafiar Yaztromo! Depois de passar a calma noite na floresta, você sobe a torre de Yaztromo no meio da manhã do dia seguinte. Você o segue pela escadaria em caracol até uma ampla sala no topo da torre. Prateleiras, cristaleiras e armários se espalham pelas paredes, cheios de garrafas, potes de vidro e livros, caixas e toda variedade de estranhos objetos. Yaztromo cai sentado na sua velha cadeira de carvalho, parecendo momentaneamente muito cansado e de longa jornada. Ele põe a mão no bolso e tira dali um delicado par de óculos de armação de ouro. Depois de colocá-los no nariz, ele observa você furtivamente sobre eles, e você se sente bastante intimidado com aquele olhar penetrante. Finalmente, ele diz: "Qualquer um que espere derrotar Malbordus tem que conhecer um mínimo de magia. Você parece bastante inteligente para aprender mas não acho que tenha tempo suficiente para absorver os dez encantos que possuía de ensinar a você. Falando nisso, gostaria que você compreendesse o quanto é privilegiado por poder aprender minha magia. Mas uma crise é uma crise. Agora, vamos começar. Que encantos devo ensinar? Você pode optar pelo encanto de Abrir Portas, do Sono das Criaturas, da Flecha Mágica, do Idioma, de Ler Símbolos, da Luz, do Fogo, de Saltar, de Detectar Armadilha e de Criar Água."', '[{"texto": "Abrir Portas", "numero": 1, "paragrafo": 12}, {"texto": "Sono das Criaturas", "numero": 2, "paragrafo": 58}, {"texto": "Flecha Mágica", "numero": 3, "paragrafo": 136}, {"texto": "Idioma", "numero": 4, "paragrafo": 194}, {"texto": "Ler Símbolos", "numero": 5, "paragrafo": 391}, {"texto": "Luz", "numero": 6, "paragrafo": 223}, {"texto": "Fogo", "numero": 7, "paragrafo": 264}, {"texto": "Saltar", "numero": 8, "paragrafo": 301}, {"texto": "Detectar Armadilha", "numero": 9, "paragrafo": 342}, {"texto": "Criar Água", "numero": 10, "paragrafo": 367}]', 'normal', false, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.aventuras_paragrafos VALUES (2, 'templo-do-terror', 58, 'Yaztromo explica que seu encanto do Sono das Criaturas fará dormir qualquer criatura humanoide. Ele conta para você as palavras necessárias para lançar o encanto e diz que ele praticamente nada exigirá de suas forças, somente 1 ponto de ENERGIA a cada vez que você o utilizar. Volte para 34, depois de ter anotado o encanto e seu custo em ENERGIA na sua Folha de Aventuras.', '[{"texto": "Voltar e escolher outro encanto", "numero": 1, "paragrafo": 34}]', 'normal', false, NULL, NULL, NULL, NULL, NULL);


--
-- Data for Name: aventuras_progresso; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.aventuras_progresso VALUES (1, '123456', 'templo-do-terror', 1, '[1]', '[]', '{}', NULL, NULL, 10, 0, '2026-02-18 21:45:31.209504', '2026-02-18 21:45:31.209504', false, NULL);
INSERT INTO public.aventuras_progresso VALUES (2, '5326646936', 'templo-do-terror', 34, '[1, 58, 34]', '[]', '{}', NULL, NULL, 10, 0, '2026-02-18 22:53:36.687921', '2026-02-18 23:09:06.777844', false, NULL);


--
-- Data for Name: aventuras_stats; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: bestiario_cidadela; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.bestiario_cidadela VALUES ('Rato Atroz (Gutash)', 13, 18, '+4', '1d6+2', 5, 100);
INSERT INTO public.bestiario_cidadela VALUES ('Yusdrayl (Feiticeira)', 15, 21, '+2', '1d4', 30, 900);
INSERT INTO public.bestiario_cidadela VALUES ('Goblin Guerreiro', 13, 7, '+4', '1d6+2', 3, 50);
INSERT INTO public.bestiario_cidadela VALUES ('Robgoblin Guerreiro', 14, 8, '+4', '1d8+2', 4, 75);
INSERT INTO public.bestiario_cidadela VALUES ('Balsag (Bugbear)', 17, 36, '+6', '1d8+4', 20, 450);
INSERT INTO public.bestiario_cidadela VALUES ('Bugbear Jardineiro', 17, 16, '+5', '2d4+3', 10, 300);
INSERT INTO public.bestiario_cidadela VALUES ('Thoqqua', 20, 16, '+5', '1d8+4', 0, 600);
INSERT INTO public.bestiario_cidadela VALUES ('Calcryx (Filhote Dragão)', 17, 32, '+5', '1d10+3', 0, 1500);
INSERT INTO public.bestiario_cidadela VALUES ('Sacerdote-Troll', 16, 42, '+6', '1d8+4', 50, 1800);
INSERT INTO public.bestiario_cidadela VALUES ('Sir Bradford (Corrompido)', 18, 20, '+6', '1d10+3', 15, 900);
INSERT INTO public.bestiario_cidadela VALUES ('Sharwyn (Corrompida)', 15, 16, '+4', '1d6+1', 10, 600);
INSERT INTO public.bestiario_cidadela VALUES ('Goblin Salteador', 15, -5, '+3', '1d6', 2, 25);
INSERT INTO public.bestiario_cidadela VALUES ('Rato Atroz Secundário', 12, 4, '1d4', '1d6', 0, 0);
INSERT INTO public.bestiario_cidadela VALUES ('Rato Atroz Filhote', 12, 3, '1d4', '1d6', 0, 0);
INSERT INTO public.bestiario_cidadela VALUES ('Belak o Proscrito', 15, 24, '+3', '1d6+1', 100, 300);
INSERT INTO public.bestiario_cidadela VALUES ('Durnn (Chefe Goblin)', 17, 16, '+5', '2d6+3', 25, 75);
INSERT INTO public.bestiario_cidadela VALUES ('Esqueleto Guardião', 13, 9, '+2', '1d6', 0, 25);
INSERT INTO public.bestiario_cidadela VALUES ('Jot (Quasit)', 15, 18, '+4', '1d4-1', 0, 150);
INSERT INTO public.bestiario_cidadela VALUES ('Kobold Sentinela', 12, 4, '+1', '1d4', 1, 25);
INSERT INTO public.bestiario_cidadela VALUES ('Ramo Seco', 13, 10, '+3', '1d6+1', 0, 25);
INSERT INTO public.bestiario_cidadela VALUES ('Rato Atroz', 12, 5, '+2', '1d4', 0, 25);


--
-- Data for Name: campanhas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.campanhas VALUES ('5326646936', 'sala_08', '{"hp_65": -1, "derrotado_65": true, "hp_78": -17, "derrotado_78": true, "respawns": 1}', '{}', 'inicio', 0, 1);


--
-- Data for Name: campanhas_cenas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.campanhas_cenas VALUES (1, 'cidadela_sem_sol', 'carvalhal', 'Vila de Carvalhal', 'A aventura se inicia na vila de Carvalhal, um local marcado por um ciclo de mortes misteriosas durante o solstício de inverno. Há uma Estalagem chamada Javali Véio, um empório e um pequeno posto da guarda. Os moradores estão assustados e desconfiados. Rumores falam sobre o desaparecimento dos irmãos Talgen e Sharwyn Hucrele nas ruínas próximas.', 'REGRA DE OURO DA CENA: ESTA É UMA ZONA SEGURA (TOWN). SOB NENHUMA HIPÓTESE INICIE COMBATE AQUI, MESMO QUE OS JOGADORES SEJAM AGRESSIVOS. Se tentarem brigar, narre que a guarda municipal interveio. Foco absoluto em interpretação (roleplay), entregar rumores na estalagem e guiá-los para a Ravina que leva à Cidadela.', '["ravina_entrada"]');


--
-- Data for Name: cenas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cenas VALUES ('carvalhal', 'Vila de Carvalhal (Oakhurst)', 'A pequena vila de Oakhurst ergue-se precariamente na borda da ravina. O ar é frio e o cheiro de fumaça de lareira preenche as ruas lamacentas. Aldeões desconfiados observam através de janelas. A Taverna do Velho Javali é o único lugar que parece oferecer algum calor real.', '{"norte": "estrada_velha"}');
INSERT INTO public.cenas VALUES ('estrada_velha', 'A Estrada Velha', 'Uma trilha de pedras arruinadas que serpenteia por quilômetros. Árvores retorcidas de galhos secos como garras observam seu avanço. O silêncio é interrompido apenas pelo vento. Carvalhos antigos formam uma abóbada sombria sobre o caminho.', '{"sul": "carvalhal", "norte": "ravina_escura"}');
INSERT INTO public.cenas VALUES ('ravina_escura', 'Área 0: A Ravina', 'Uma fenda profunda e estreita abre-se na terra como uma cicatriz. Dois pilares de pedra ainda estão de pé, mas a maioria está inclinada para o abismo. Uma corda grossa com nós, amarrada a um pilar, desce 15 metros até a escuridão abaixo. Marcas de pés goblin estão gravadas na face do rochedo.', '{"sul": "estrada_velha", "descer": "sala_01"}');
INSERT INTO public.cenas VALUES ('sala_01', 'Área 1: O Parapeito', 'Um parapeito de areia domina um golfo subterrâneo de escuridão a oeste. Areia, pedregulhos e ossos de pequenos animais recobrem o solo. Uma escada talhada na pedra serpenteia pela lateral, descendo às trevas.', '{"subir": "ravina_escura", "oeste": "sala_02"}');
INSERT INTO public.cenas VALUES ('sala_02', 'Área 2: Escadas Sinuosas', 'Escadas de pedra rústica descem em espiral, cobertas por uma camada espessa de poeira e teias de aranha. Os degraus estão irregulares e perigosos, cobertos por musgo escorregadio e poças de água negra.', '{"leste": "sala_01", "baixo": "sala_03"}');
INSERT INTO public.cenas VALUES ('sala_03', 'Área 3: Pátio em Ruínas', 'Um vasto pátio subterrâneo pavimentado, mas rachado. O ar é pesado e cheira a poeira secular. Estátuas sem cabeça de heróis do passado permanecem como sentinelas tristes. Portas de pedra levam para o interior da fortaleza em várias direções.', '{"subir": "sala_02", "norte": "sala_04", "oeste": "sala_05", "leste": "sala_12"}');
INSERT INTO public.cenas VALUES ('sala_04', 'Área 4: Torre em Ruínas', 'Uma torre circular de granito. O teto desabou há séculos. No chão, corpos de goblins em decomposição jazem espalhados. Um deles está empalado na parede oeste por uma lança enferrujada. Qualquer PJ que conheça Dracônico lerá a inscrição na parede: ''Ashardalon''.', '{"sul": "sala_03", "oeste": "sala_06"}');
INSERT INTO public.cenas VALUES ('sala_05', 'Área 5: Câmara Secreta', 'Uma câmara pequena e abafada, escondida atrás de uma porta secreta (Procurar CD 16). Prateleiras quebradas indicam uma antiga despensa. A passagem está armada com uma armadilha de agulha — embora o veneno já tenha evaporado, a agulha ainda causa 1 ponto de dano.', '{"leste": "sala_03"}');
INSERT INTO public.cenas VALUES ('sala_06', 'Área 6: Corredor da Aproximação', 'Um corredor longo com portas de pedra pesadas. O ar é estagnado e cheira a poeira secular. Manchas escuras no chão lembram sangue seco. Uma porta secreta na parede leva à Área 5.', '{"leste": "sala_04", "oeste": "sala_07"}');
INSERT INTO public.cenas VALUES ('sala_07', 'Área 7: Galeria das Notas de Forlorn', 'Um corredor amplo adornado com estátuas de dragão esculpidas em pedra vermelha. Dois pedestais de pedra nas paredes norte e sul sustentam globos cristalinos — o globo sul ainda emite um suave brilho e notas musicais tênues. Há um alçapão no chão que desce para o território goblin.', '{"leste": "sala_06", "norte": "sala_08", "baixo": "sala_31"}');
INSERT INTO public.cenas VALUES ('sala_31', 'Área 31: Câmara dos Estrepes', 'Este aposento de 3 metros de largura foi deliberadamente coberto com estrepes afiados. A porta ao norte foi arrancada; a sala está parcialmente bloqueada por uma parede de tijolos em ruínas de 90cm. Os goblins da área 32 surgirão nas ameias se forem alertados.', '{"cima": "sala_07", "norte": "sala_32"}');
INSERT INTO public.cenas VALUES ('sala_32', 'Área 32: Portão Goblin', 'Manchas na parede, marcas de fogueiras desgastadas e odores de criaturas de má higiene definem este aposento que serve como posto de guarda da tribo Durbuluk. Dois goblins estão parados aqui; se alertados, disparam azagaias protegidos atrás da ameida.', '{"sul": "sala_31", "norte": "sala_33"}');
INSERT INTO public.cenas VALUES ('sala_41', 'Área 41: Câmara do Chefe Goblin (Durnn)', 'Um trono de pedra erguido firmemente está encostado na parede a noroeste. Uma grande arca de ferro está diante do trono. O chefe goblin Durnn, um robgoblin, rege a tribo Durbuluk a partir desta câmara dramática situada acima do Bosque do Crepúsculo. Um poço repleto de vinhas grossas mergulha 24 metros nas profundezas.', '{"sul": "sala_40", "baixo": "sala_42"}');
INSERT INTO public.cenas VALUES ('sala_36', 'Área 36', 'As paredes desta câmara (Área 36) são de pedra talhada, cobertas por limo e inscrições antigas que sussurram segredos esquecidos.', '{"voltar": "sala_03"}');
INSERT INTO public.cenas VALUES ('sala_08', 'Área 8: Placas de Pressão', 'Uma pequena câmara com uma placa de pressão ligeiramente elevada no centro do chão. O mecanismo, se ativado, dispara setas da parte superior da porta oeste. O pó espesso e intocado sugere que esta câmara permaneceu selada há eras.', '{"sul": "sala_07", "norte": "sala_09"}');
INSERT INTO public.cenas VALUES ('sala_09', 'Área 9: O Enigma do Dragão', 'Uma câmara repleta de poeira como neve cinzenta. Na parede norte, uma escultura de dragão em mármore branco com relevos vermelhos. Qualquer criatura que se aproxime a 1,5m ouvirá a estátua entoar em Comum: ''Surgimos da terra sem ninguém nos parir; Desaparecemos se alguém tentar nos roubar.'' Resposta: ESTRELAS.', '{"sul": "sala_08", "leste": "sala_10"}');
INSERT INTO public.cenas VALUES ('sala_10', 'Área 10: A Guarda de Honra', 'Um corredor flanqueado por alcova nas paredes leste e oeste. Cada alcova contém uma figura humana vestida em mármore branco com véus vermelhos. As estátuas lembram cavaleiros em cotas de malha. No fundo, um arco de pedra abre para uma sala larga ao norte.', '{"oeste": "sala_09", "norte": "sala_11", "sul": "sala_12"}');
INSERT INTO public.cenas VALUES ('sala_11', 'Área 11: Tumba do Sacerdote do Dragão', 'O teto e as paredes estão rachados e quebrados, mas a câmara resiste. Um sarcófago de mármore maciço com mais de 2,5 metros de comprimento jaz no centro. A pedra foi talhada com motivos dracônicos e a cabeceira é idêntica à face de um dragão. Seis trincos de ferro enferrujado trancam a tampa. Uma chama esverdeada permanente ilumina a câmara.', '{"sul": "sala_10"}');
INSERT INTO public.cenas VALUES ('sala_12', 'Área 12: Saguão de Entrada Kobold', 'A entrada principal para o território Kobold. Barricadas e ossos espalhados marcam o lugar. O cheiro de escamas e fumaça preenche o ar. Ao norte começam os corredores controlados pelos Kobolds da tribo de Yusdrayl.', '{"oeste": "sala_03", "norte": "sala_13", "sul": "sala_10"}');
INSERT INTO public.cenas VALUES ('sala_13', 'Área 13: Corredor de Entrada Kobold', 'Um corredor com barricadas improvisadas de kobolds. O fedor de muitos corpos em área tão pequena saturou o ar. Um pequeno círculo de brasas no meio foi construído com lajes quebradas.', '{"sul": "sala_12", "norte": "sala_15", "oeste": "sala_14", "leste": "sala_16"}');
INSERT INTO public.cenas VALUES ('sala_14', 'Área 14: Despensa do Dragão', 'Ratos e fezes enchem o aposento. Uma pequena barreira evita que os ratos escapem com facilidade. Os kobolds alimentavam os ratos com grilos e fungos para servir de comida ao filhote de dragão. Desde o sequestro, os ratos enfraqueceram a barreira.', '{"leste": "sala_13"}');
INSERT INTO public.cenas VALUES ('sala_15', 'Área 15: Fora da Gaiola (Meepo)', 'Símbolos e grafias em tinta verde decoram essa câmara grande e arruinada. Um grande poço no centro tem evidências de fogueira recente. Uma jaula metálica arrebentada e vazia fica na parede sul. Sobre um saco de dormir perto da tribuna, o kobold Meepo, Guardião de Dragões, dorme num sono repleto de pesadelos.', '{"sul": "sala_13"}');
INSERT INTO public.cenas VALUES ('sala_16', 'Área 16: Kobolds Sentinelas', 'O fedor de muitos corpos amontoados por muito tempo numa área tão pequena saturou o ar. Um pequeno círculo de brasas no meio da câmara foi construído com lajes quebradas. Diversos humanóides pequenos com escamas e chifres habitam a câmara — são as sentinelas kobolds.', '{"oeste": "sala_13", "leste": "sala_17"}');
INSERT INTO public.cenas VALUES ('sala_17', 'Área 17: Câmara Dracônica', 'Uma sala cerimonial ampla com pilares esculpidos com dragões. O chão está coberto por tapetes feitos de cabelo entrelaçado e plantas mortas reunidos em volta de um fogo.', '{"oeste": "sala_16", "norte": "sala_19", "leste": "sala_18"}');
INSERT INTO public.cenas VALUES ('sala_18', 'Área 18: Prisão de Guerra', 'Quatro humanóides pequenos com chifres estão rudemente amarrados com cordas brutas numa grande lança perto da entrada. Os kobolds mantêm guerreiros goblins capturados aqui, exigindo resgate. Algemas corroídas estão presas nas paredes.', '{"oeste": "sala_17"}');
INSERT INTO public.cenas VALUES ('sala_19', 'Área 19: Salão dos Dragões', 'Uma fileira dupla de colunas de mármore esculpidas em relevo com dragões estende-se por todo o interior. Os entalhes retratam dragões alados e humanóides pequenos e com chifres patrulham frequentemente a área.', '{"sul": "sala_17", "norte": "sala_21", "leste": "sala_26"}');
INSERT INTO public.cenas VALUES ('sala_20', 'Área 20: Colônia Kobold', 'Este é o principal refugio dos kobolds que invadiram a Cidadela. Diversas fogueiras pequenas iluminam o aposento amplo e alto. Utensílios de uma cozinha primitiva estão visíveis em meio à fumaça. Diversas figuras pequenas estão ocupadas trabalhando ou brincando. Senha para entrar: ''milho que roda'' (em Dracônico).', '{"leste": "sala_21"}');
INSERT INTO public.cenas VALUES ('sala_21', 'Área 21: O Trono do Dragão (Yusdrayl)', 'Um trono baixo se ergue, parcialmente construído com pedaços de altar quebrados sobre um alçapão a leste. Vestida em trajes regais e sentada no trono, Yusdrayl governa com um grupo de 6 sentinelas ao redor. O topo do altar contém diversos itens preciosos. Uma chave metálica está firmemente presa na boca aberta do dragão esculpido.', '{"sul": "sala_19", "norte": "sala_22", "oeste": "sala_20", "leste": "sala_25"}');
INSERT INTO public.cenas VALUES ('sala_22', 'Área 22: Despensa Kobold', 'O odor de carne podre permeia esta câmara. Ganchos de ferro enferrujado pendurados no teto sustentam carcaças dobradas de grandes vermes, fungos enormes e carcaças maciças de insetos. Os kobolds estocam e preparam comida para a tribo aqui.', '{"sul": "sala_21", "norte": "sala_23"}');
INSERT INTO public.cenas VALUES ('sala_23', 'Área 23: Acesso ao Subterrâneo', 'As pedras de pavimentação em ruínas, soltas e quebradas, desabaram parcialmente revelando um túnel. A passagem é rústica: largura, altura e direção variam muito. Equipamentos de caça estão empilhados e três carrinolas podem ser vistas num canto. Três sentinelas estão de guarda. O túnel conduz a quilômetros de escuridão além da aventura.', '{"sul": "sala_22"}');
INSERT INTO public.cenas VALUES ('sala_24', 'Área 24: Passagem do Fosso', 'Um corredor de 6 metros de comprimento controlado pelos kobolds. Ambas as portas estão fechadas e trancadas. O corredor termina num alçapão escondido — uma armadilha goblin. Uma passarela de 30cm de largura permite acesso seguro caso a armadilha seja descoberta.', '{"norte": "sala_26", "sul": "sala_17"}');
INSERT INTO public.cenas VALUES ('sala_25', 'Área 25: Desolação', 'Vazia e escura, esta câmara isolada contém apenas dejetos de ratos, lajes em pedaços e manchas impossíveis de identificar. Trilhas de humanóides Médios usando botas passaram por aqui nos últimos seis meses. Uma das áreas conectadas tem uma armadilha — consulte a área 31.', '{"oeste": "sala_21", "norte": "sala_29"}');
INSERT INTO public.cenas VALUES ('sala_26', 'Área 26: Fonte Seca', 'Poeira e pedaços estranhos de escombros de pedra estão espalhados pelo chão. Uma fonte ornamental foi construída na parede leste — embora esteja quebrada, manchada e seca, a escultura de um dragão mergulhando conserva sua beleza. Inscrição em Dracônico: ''Que haja fogo'' — que invoca uma poção de sopro de dragão.', '{"oeste": "sala_19", "norte": "sala_27", "sul": "sala_24"}');
INSERT INTO public.cenas VALUES ('sala_27', 'Área 27: Santuário', 'A porta de pedra esculpida que conduz ao santuário tem uma tranca especial e armadilha de pêndulo. Os entalhes mostram dragões esqueletizados. Um altar tem motivos de dragões e uma vela encantada. Cinco sarcófagos empoeirados nas paredes guardam esqueletos protetores. Inscrição em Dracônico: ''Canalize o bem e abra o caminho.''', '{"sul": "sala_26", "norte": "sala_28"}');
INSERT INTO public.cenas VALUES ('sala_28', 'Área 28: Celas Infestadas', 'Esta seção do saguão contém seis portas que conduzem a pequenas celas (A até F). Três ratos atrozes habitam as celas b, c e e. Os ninhos emaranhados de pedra, osso e fungos contêm peças brilhantes recolhidas pelos habitantes.', '{"sul": "sala_27", "norte": "sala_29"}');
INSERT INTO public.cenas VALUES ('sala_29', 'Área 29: Armadilhas Antigas', 'O solo pavimentado contém dois alçapões abertos e bloqueados por barras de ferro. Uma fonte seca na parede norte tem inscrição em Dracônico: ''Que haja morte'' — uma armadilha de nuvem de veneno. O rastro do grupo de aventureiros perdidos circunda as armadilhas.', '{"sul": "sala_28", "norte": "sala_30", "leste": "sala_25"}');
INSERT INTO public.cenas VALUES ('sala_30', 'Área 30: Mamãe Rato (Gutash)', 'O cheiro de carne apodrecida espalha-se no ar, subindo das carcaças muito roídas de vários ratos vermes menores e alguns corpos de aparência humanóide suspeita. No centro, um ninho particularmente grande e desprezível abriga Gutash — a Mamãe Rato, duas vezes o tamanho de um rato atroz comum, com 1,8m de comprimento.', '{"sul": "sala_29"}');
INSERT INTO public.cenas VALUES ('sala_33', 'Área 33: Sala de Prática', 'Quatro goblins designados para vigiar este aposento praticam tiro ao alvo com azagaias, usando bonecões de estopa vagamente parecidos com humanos e elfos. No resto do tempo, se embriagam com o licor goblin da tribo.', '{"sul": "sala_32", "norte": "sala_36a", "leste": "sala_34"}');
INSERT INTO public.cenas VALUES ('sala_34', 'Área 34: Prisão Militar Goblin', 'A imundície reina nessa masmorra comprida e baixa. Três pequenos humanóides com chifres (kobolds) estão rudemente amarrados com cordas brutas. Mais ao fundo, um gnomo exausto definha dentro de uma jaula de ferro enferrujada pequena demais até para ele: Erky Timbers, clérigo/guerreiro, preso há um ano.', '{"oeste": "sala_33"}');
INSERT INTO public.cenas VALUES ('sala_35', 'Área 35: Corredor com Armadilha', 'Este corredor de aparência comum contém uma armadilha: um alçapão no solo imediatamente na frente da entrada que conduz à sala dos troféus. A porta que conduz adiante está fechada e trancada. No fundo do poço há um anel de ouro com inseto de safira (25 PO).', '{"norte": "sala_36a", "sul": "sala_37"}');
INSERT INTO public.cenas VALUES ('sala_37', 'Área 37: Sala dos Troféus (Calcryx!)', 'Cabeças de animais empalhados adornam as paredes sujas. Alguns troféus horríveis dividem as paredes com animais, incluindo um par de rostos de kobolds. Uma corrente de ferro enferrujada jaz torta no centro. Pequenas camadas de gelo recobrem partes das paredes — aqui está Calcryx, o filhote de dragão branco dos kobolds, roubado pelos goblins!', '{"norte": "sala_35", "leste": "sala_38"}');
INSERT INTO public.cenas VALUES ('sala_38', 'Área 38: Passagem Goblin', 'Esta câmara é usada para estocar água salgada, carne estragada e 2,5 litros de óleo em bom estado — realmente útil para os personagens. Diversos barris de pudim elfico. Qualquer personagem que leia Goblin pode decifrar a escrita externa dos barris: ''pudim elfico''.', '{"sul": "sala_36a", "oeste": "sala_37", "norte": "sala_39"}');
INSERT INTO public.cenas VALUES ('sala_39', 'Área 39: Fumaça do Dragão', 'Vitrais e janelas fraturadas existentes na parede preenchem este saguão com uma fumaça que atrapalha a visão. Uma fileira dupla de figuras de mármore esculpidas com dragões enlaçados em relevo estende-se por todo o salão. A fumaça nunca atinge níveis sufocantes, mas concede disfarce parcial aos goblins acostumados a ela.', '{"sul": "sala_36b", "oeste": "sala_38", "norte": "sala_40"}');
INSERT INTO public.cenas VALUES ('sala_40', 'Área 40: Vilarejo Goblin', 'Outrora uma catedral, agora um covil goblin recoberto pela sujeira espessa de vários anos de habitação. Impressões nas paredes e cinzeiros no solo cheio de fungos com brilho violeta iluminam a sala. Sob a luz fraca, dezenas de goblins cuidam de seus afazeres diários: dormir, preparar comida, discutir, comer, lutar, afiar armas...', '{"sul": "sala_36c", "leste": "sala_39", "norte": "sala_41"}');
INSERT INTO public.cenas VALUES ('sala_42', 'Área 42: Central de Adubo', 'O Bosque do Crepúsculo contém uma grande variedade de vida vegetal natural e sobrenatural cujo crescimento é auxiliado pela aplicação de adubo, sob a direção de Belak. Dois ramos secos estão enraizados nesta câmara, alimentando-se. Dois esqueletos servos de Belak remexem o adubo e reúnem matéria-prima.', '{"cima": "sala_41", "norte": "sala_43"}');
INSERT INTO public.cenas VALUES ('sala_43', 'Área 43: O Grande Caçador (Balsag)', 'O chão rústico desta caverna está manchado e molhado. Fungos brilhantes iluminam a alcova leste, que contém uma cama com peles e cabelos de animais enrolados, uma prancheta dentada de madeira onde diversas armas rústicas estão presas, e um casaco de pele negra. Balsag, o bugbear, e seus dois ratos caçadores habitam aqui.', '{"sul": "sala_42", "norte": "sala_47", "leste": "sala_44"}');
INSERT INTO public.cenas VALUES ('sala_44', 'Área 44: Fenda', 'O túnel é interrompido por algum desastre geológico do passado que partiu a terra. Ele continua depois da fenda, mas deslocou-se 3 metros para o oeste. A fenda não contém fungos fosforescentes e o cheiro de enxofre supera qualquer outro. O chão tem uma depressão de 60cm e está repleto de buracos de 30cm de diâmetro.', '{"oeste": "sala_43", "norte": "sala_45"}');
INSERT INTO public.cenas VALUES ('sala_45', 'Área 45: Nódulo da Fenda (Thoqqua)', 'A fenda se alarga, criando uma antecâmara de pedra. Pequenos buracos de 30cm de diâmetro cavam o solo. Um deles emite uma luz flamejante. O nódulo fica perto de uma grande concentração de minerais, frequentemente visitada pelos thoqqua que se alimentam de minério. Um thoqqua — verme incandescente branco-alaranjado — habita aqui.', '{"sul": "sala_44"}');
INSERT INTO public.cenas VALUES ('sala_46', 'Área 46: O Antigo Altar', 'Uma porta de pedra conduz a este aposento fechada e emperrada (Força CD 15 para abrir). Um mosaico de azulejos desbotados recobre parte das paredes. No centro da câmara há um pedestal fino composto de metal enferrujado na forma de um dragão ereto. Na boca do dragão há uma bandeja vazia. O objeto precioso guardado aqui pelo antigo culto dos dragões se foi.', '{"leste": "sala_47"}');
INSERT INTO public.cenas VALUES ('sala_47', 'Área 47: Comunidade Goblin de Belak', 'Uma fileira dupla de colunas de mármore esculpida com dragões percorre toda a extensão do salão, embora a maioria esteja completamente envolta com fungos luminescentes. O chão rachado e manchado tem várias mesas pequenas de madeira com argila e pilões, vasilhas cheias de folhas amassadas e caules de fungos. Oito goblins servos de Belak habitam as câmaras conectadas.', '{"sul": "sala_43", "oeste": "sala_46", "norte": "sala_49"}');
INSERT INTO public.cenas VALUES ('sala_48', 'Área 48: Galeria (Jardins de Belak)', 'Belak está transformando estas duas galerias em estufas para várias espécies de gramíneas da superfície. Ele está tentando cultivar a vegetação da superfície no Subterrâneo usando a luz dos fungos luminescentes. As galerias têm um único jardineiro bugbear que usa uma foice longa.', '{"sul": "sala_47", "norte": "sala_49"}');
INSERT INTO public.cenas VALUES ('sala_49', 'Área 49: Arvoredo (Centro do Bosque)', 'Existem quatro arvoredos no nível inferior. Cada um contém elementos variados. O odor incomum de algo podre, misturado com o brilho verde-pálido dos fungos, dá uma sensação de irrealidade. Goblin servos de Belak, esqueletos, um thoqqua jovem e bugbears habitam as diferentes câmaras deste complexo central.', '{"sul": "sala_47", "norte": "sala_54", "oeste": "sala_50", "leste": "sala_52"}');
INSERT INTO public.cenas VALUES ('sala_50', 'Área 50: Templo de Ashardalon', 'Blocos de granito esculpidos com dragões recobrem as paredes e o teto, embora muitos estejam quebrados e arruinados. Uma enorme estátua de mármore representando um dragão imponente pode ser vista na parede oeste. Os globos oculares do dragão emitem uma luz vermelha que preenche toda a câmara. Um azulejo de pedra vermelha de 1m de diâmetro jaz no solo. Uma Sombra espreita atrás da estátua.', '{"leste": "sala_49", "norte": "sala_51"}');
INSERT INTO public.cenas VALUES ('sala_51', 'Área 51: Biblioteca dos Dragões', 'Estantes de pedra inclinadas ou completamente destruídas preenchem esta câmara, mas uma trilha limpa conecta duas portas de madeira nas paredes opostas. O resto de páginas rasgadas e queimadas, encadernações e pergaminhos forma pilhas desordenadas nos cantos. Três testes de Procurar (CD 20) revelam pergaminhos arcanos valiosos.', '{"sul": "sala_50", "norte": "sala_53"}');
INSERT INTO public.cenas VALUES ('sala_52', 'Área 52: Passagem Subterrânea', 'Degraus úmidos e em ruínas criam um declive acentuado. Um corredor de pedra de 3m de largura e 2,4m de altura cria uma passagem a cerca de 2m sob a área 49. Os degraus descem 4,5m, conectando a passagem em ambos os lados. A passagem está muito úmida e completamente destruída.', '{"oeste": "sala_49"}');
INSERT INTO public.cenas VALUES ('sala_53', 'Área 53: Conhecimento da Natureza (Aposentos de Belak)', 'A porta está fechada (Abrir Fechaduras CD 25) — apenas Belak tem a chave. Uma camada de terra recobre o chão. Prateleiras de madeira rústica, cheias de tomos e pergaminhos mal-organizados, alinham-se nas paredes norte e leste. Fungos pendurados no teto nutrem diversos arbustos e brotos pálidos que crescem no solo. Aqui Belak guarda seu conhecimento.', '{"sul": "sala_51"}');
INSERT INTO public.cenas VALUES ('sala_54', 'Área 54: Portão do Bosque', 'Quatro goblins separam galhos e pilhas de raízes no chão desta câmara arqueada. As paredes do sul desabaram e revelam uma caverna ampla. Nódulos de fungos luminescentes estendem-se sobre as paredes nuas e o teto alto, iluminando um bosque irregular de ramos, arbustos, brotos de árvores e outras plantas doentes. Paredes arruinadas e torres vazias emergem do bosque como ilhas no oceano.', '{"sul": "sala_49", "norte": "sala_55"}');
INSERT INTO public.cenas VALUES ('sala_55', 'Área 55: Bosque do Crepúsculo', 'Os galhos são a planta da superfície melhor sucedida pelo cultivo de Belak, ainda que pareçam pálidos, doentes e tenham as folhas ressequidas. Dez ramos secos estão espalhados pelo Bosque do Crepúsculo, banhando-se na radiação fraca dos fungos. Conforme os PJs avançam, confrontam 1d4 ramos secos a cada 15 metros percorridos.', '{"sul": "sala_54", "norte": "sala_56"}');
INSERT INTO public.cenas VALUES ('sala_56', 'Área 56: A Árvore Gulthias (BOSS FINAL)', 'As paredes do pátio têm apenas 6 metros de altura, enquanto o trio cheio de estalagmites alcança 15 metros acima do solo. No centro ergue-se a colossal Árvore Gulthias — uma abominação de madeira negra e galhos enegrecidos que se elevam como uma mão faminta. Belak, o Proscrito (druida de 6° nível), aguarda nas sombras. Ao lado da árvore: Sir Bradford e Sharwyn, corrompidos por ela.', '{"sul": "sala_55"}');
INSERT INTO public.cenas VALUES ('sala_36a', 'Área 36: Salteadores Goblins (Quartel A)', 'Mau cheiro, lixo, carne podre e pedaços semi-devorados de animais denotam os anos de utilização deste aposento por criaturas de pouca higiene. Seis redes feitas de peles e tecidos esfarrapados estão penduradas ao redor de um fogão de lenha muito utilizado. Seis goblins ''salteadores'' habitam este quartel.', '{"sul": "sala_33", "norte": "sala_38", "leste": "sala_36b"}');
INSERT INTO public.cenas VALUES ('sala_36b', 'Área 36: Salteadores Goblins (Quartel B)', 'Outro quartel de salteadores goblins, idêntico em cheiro e desordem ao anterior. Seis goblins se autodenominam orgulhosamente de ''salteadores''. Utensílios velhos e armas quebradas estão amontoados indiscriminadamente com armaduras gastas num dos cantos.', '{"oeste": "sala_36a", "norte": "sala_39", "leste": "sala_36c"}');
INSERT INTO public.cenas VALUES ('sala_36c', 'Área 36: Salteadores Goblins (Quartel C)', 'O terceiro quartel de salteadores. As mesmas condições deploráveis dos outros dois. Odres de vinho estragado e restos podres formam o mobiliário principal. Uma saída a norte leva à Fumaça do Dragão.', '{"oeste": "sala_36b", "norte": "sala_40"}');


--
-- Data for Name: criacao_ficha; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: diario_thorak; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.diario_thorak VALUES (1, '2026-02-19 16:48:06.591611', 'O anão Thorak encarou Belak e a Árvore Gulthias. O destino de Carvalhal foi selado.', 'clareira_44', 8);


--
-- Data for Name: documentos_aventura; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.documentos_aventura VALUES (1, 'O Mapa de Belak', 'Um rascunho em couro mostrando a conexão entre a fenda (Área 45) e o mundo exterior. Revela que o druida tinha planos de expandir o bosque para a superfície.', 'laboratorio_35');
INSERT INTO public.documentos_aventura VALUES (2, 'Inscrição da Árvore', 'Diz a lenda que a árvore nasceu de uma estaca cravada no coração de um vampiro chamado Gulthias. O mal dele agora flui pela seiva.', 'clareira_44');
INSERT INTO public.documentos_aventura VALUES (3, 'Registros de Oakhurst', 'Uma lista de nomes de aldeões que compraram a maçã branca nos últimos 10 anos. Muitos deles desapareceram ou "mudaram de personalidade".', 'conclusao_46');


--
-- Data for Name: encontros_salas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.encontros_salas VALUES (78, 'sala_32', 'Goblin Salteador', 2, 'sempre', false);
INSERT INTO public.encontros_salas VALUES (101, 'area_1', 'Rato Atroz Secundário', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (102, 'area_1', 'Rato Atroz Filhote', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (65, 'sala_01', 'Rato Atroz', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (66, 'sala_05', 'Esqueleto Guardião', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (67, 'sala_10', 'Jot (Quasit)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (68, 'sala_11', 'Sacerdote-Troll', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (69, 'sala_13', 'Kobold Sentinela', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (70, 'sala_16', 'Kobold Sentinela', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (71, 'sala_19', 'Kobold Sentinela', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (72, 'sala_21', 'Yusdrayl (Feiticeira)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (73, 'sala_21', 'Kobold Sentinela', 6, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (74, 'sala_27', 'Esqueleto Guardião', 5, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (75, 'sala_28', 'Rato Atroz', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (76, 'sala_30', 'Rato Atroz (Gutash)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (77, 'sala_30', 'Rato Atroz', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (79, 'sala_33', 'Goblin Salteador', 4, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (80, 'sala_36a', 'Goblin Salteador', 6, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (81, 'sala_36b', 'Goblin Salteador', 6, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (82, 'sala_36c', 'Goblin Salteador', 6, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (83, 'sala_37', 'Calcryx (Filhote Dragão)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (84, 'sala_40', 'Goblin Salteador', 4, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (85, 'sala_40', 'Robgoblin Guerreiro', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (86, 'sala_41', 'Durnn (Chefe Goblin)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (87, 'sala_41', 'Goblin Salteador', 4, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (88, 'sala_41', 'Robgoblin Guerreiro', 3, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (89, 'sala_41', 'Ramo Seco', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (90, 'sala_42', 'Ramo Seco', 2, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (91, 'sala_42', 'Esqueleto Guardião', 2, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (92, 'sala_43', 'Balsag (Bugbear)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (93, 'sala_43', 'Rato Atroz', 2, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (94, 'sala_45', 'Thoqqua', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (95, 'sala_48', 'Bugbear Jardineiro', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (96, 'sala_55', 'Ramo Seco', 10, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (97, 'sala_56', 'Belak o Proscrito', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (98, 'sala_56', 'Sir Bradford (Corrompido)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (99, 'sala_56', 'Sharwyn (Corrompida)', 1, 'sempre', true);
INSERT INTO public.encontros_salas VALUES (100, 'sala_56', 'Ramo Seco', 3, 'sempre', true);


--
-- Data for Name: grimorio_cidadela; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.grimorio_cidadela VALUES (1, 'Mísseis Mágicos', 1, '30 metros', 'Cria 3 dardos de energia que acertam automaticamente. Dano: 1d4+1 por dardo.');
INSERT INTO public.grimorio_cidadela VALUES (2, 'Curar Ferimentos Leves', 1, 'Toque', 'Cura 1d8+1 pontos de vida de uma criatura.');
INSERT INTO public.grimorio_cidadela VALUES (3, 'Emaranhar', 1, '120 metros', 'Plantas prendem as criaturas em uma área. Exige teste de Reflexos (CD 13) para não ficar imóvel.');
INSERT INTO public.grimorio_cidadela VALUES (4, 'Clava Mística (Shillelagh)', 0, 'Toque', 'Transforma um pedaço de madeira em uma arma mágica. Dano aumenta para 1d6+2.');
INSERT INTO public.grimorio_cidadela VALUES (5, 'Mísseis Mágicos', 1, '30 metros', 'Cria 3 dardos de energia que acertam automaticamente. Dano: 1d4+1 por dardo.');
INSERT INTO public.grimorio_cidadela VALUES (6, 'Curar Ferimentos Leves', 1, 'Toque', 'Cura 1d8+1 pontos de vida de uma criatura.');
INSERT INTO public.grimorio_cidadela VALUES (7, 'Emaranhar', 1, '120 metros', 'Plantas prendem as criaturas em uma área. Exige teste de Reflexos (CD 13) para não ficar imóvel.');
INSERT INTO public.grimorio_cidadela VALUES (8, 'Clava Mística (Shillelagh)', 0, 'Toque', 'Transforma um pedaço de madeira em uma arma mágica. Dano aumenta para 1d6+2.');


--
-- Data for Name: itens_magicos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.itens_magicos VALUES (1, 'Shatterspike (Quebra-Espadas)', 'Espada Longa +1. Se o portador tentar quebrar a arma ou objeto de um inimigo, o dano é sempre considerado um Crítico.', 2000);
INSERT INTO public.itens_magicos VALUES (2, 'Cajado de Entalhe (Gulthias Staff)', 'Cajado de madeira negra. Permite ao portador usar a magia "Emaranhar" 1x por dia. O portador não é atacado por Ramos Secos (Twigs).', 1500);
INSERT INTO public.itens_magicos VALUES (3, 'Fruto da Árvore Gulthias (Vermelho)', 'Maçã milagrosa. Cura todas as doenças e recupera todos os PVs instantaneamente.', 0);
INSERT INTO public.itens_magicos VALUES (4, 'Fruto da Árvore Gulthias (Branco)', 'Maçã da Morte. Contém sementes que, se plantadas, dão origem a um novo Ramo Seco. Se ingerida, funciona como um veneno potente.', 0);


--
-- Data for Name: jogadores; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.jogadores VALUES ('5326646936', 'Spock', 'Patrulheiro', 'Meio-Elfo', 'Soldado', 1, 125, 10, 10, 10, 10, 14, 11, 12, 13, 9, 0, 2, 0, 1, 1, -1, 2, NULL, NULL, 13, 2, '1d10', 0, 0, 0, '[]', 9, '"\u2022 Armadura de Couro\n\u2022 Arco Longo\n\u2022 20 Flechas\n\u2022 2 Espadas Curtas\n\u2022 Pacote de Explorador"', NULL, false);


--
-- Data for Name: logs_navegacao; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.logs_navegacao VALUES (1, '5326646936', 'null', 'sigo pelo parapeito', NULL, false, '2026-03-12 18:03:26.698248');
INSERT INTO public.logs_navegacao VALUES (2, '5326646936', 'ravina', 'sigo pelo parapeito', 'undefined', true, '2026-03-12 18:07:22.213238');
INSERT INTO public.logs_navegacao VALUES (3, '5326646936', 'parapeito_01', 'Grishnu olha para as duas opções. Saguão de Entrada — ali pode ter informação.
Sigo para o Saguão de Entrada.', 'undefined', true, '2026-03-12 18:08:20.14525');
INSERT INTO public.logs_navegacao VALUES (4, '5326646936', 'saguao_02', '🚶 Grishnu se move para Saguão de Entrada

Um hall de entrada em colapso. O teto parcialmente desabou, deixando pilhas de entulho pelo chão. Colunas rachadas ainda sustentam o que resta da estrutura. Através da poeira, você vê marcas de tochas nas paredes — alguém esteve aqui recentemente.

━━━━━━━━━━━━━━━━
🗺️ Saídas disponíveis: O Parapeito, Pátio das Estátuas, Escadas Sinuosas

❓ O que você faz?', 'undefined', true, '2026-03-12 18:08:55.493864');
INSERT INTO public.logs_navegacao VALUES (5, '5326646936', 'saguao_02', 'examino as marcas de tocha nas paredes', NULL, false, '2026-03-12 18:17:24.225271');
INSERT INTO public.logs_navegacao VALUES (6, '5326646936', 'saguao_02', 'Você se aproxima das marcas de tocha nas paredes, notando que a poeira acumulada revela um padrão que sugere uma passagem frequente. As marcas parecem frescas, como se alguém tivesse passado por aqui recentemente, talvez em busca de abrigo ou para explorar a cidadela abandonada. Enquanto observa, você percebe que algumas áreas nas paredes estão mais desgastadas, indicando que as tochas foram retiradas e colocadas de volta com regularidade.

No entanto, ao se concentrar nas marcas, uma sensação de alerta surge. Você nota uma corda esticada entre duas colunas, quase invisível na penumbra, que parece ser uma armadilha rudimentar. Se você não tomar cuidado, pode acionar uma queda de pedras. O saguão de entrada continua a se desmoronar ao seu redor, e você se pergunta se deve prosseguir com cautela ou explorar mais a fundo. O que você faz?', NULL, false, '2026-03-12 18:18:03.403522');
INSERT INTO public.logs_navegacao VALUES (7, '5326646936', 'saguao_02', 'examino a armadilha com cuidado para tentar desarmá-la', NULL, false, '2026-03-12 18:26:43.699104');
INSERT INTO public.logs_navegacao VALUES (8, '5326646936', 'saguao_02', 'Já mandei 3 mensagens e não mexe o fluxo', NULL, false, '2026-03-12 18:26:43.759805');
INSERT INTO public.logs_navegacao VALUES (9, '5326646936', 'saguao_02', 'examino a armadilha com cuidado para tentar desarmá-la', NULL, false, '2026-03-12 18:26:44.375271');
INSERT INTO public.logs_navegacao VALUES (10, '5326646936', 'saguao_02', 'examino a armadilha com cuidado para tentar desarmá-la', NULL, false, '2026-03-12 18:26:45.174934');
INSERT INTO public.logs_navegacao VALUES (11, '5326646936', 'saguao_02', 'Grishnu sorri. Alguém montou isso aqui — goblins ou kobolds provavelmente. Segue em frente.
Sigo pelas Escadas Sinuosas.', 'escadas_02', true, '2026-03-12 18:27:47.800323');
INSERT INTO public.logs_navegacao VALUES (12, '5326646936', 'escadas_02', 'Grishnu olha para os três ratos. Sorri.
Ataco o rato mais próximo com meu machado!', NULL, false, '2026-03-12 18:33:48.484565');
INSERT INTO public.logs_navegacao VALUES (13, '5326646936', 'escadas_02', 'Grishnu olha para os três ratos. Sorri.
Ataco o rato mais próximo com meu machado!', NULL, false, '2026-03-12 18:36:52.780003');
INSERT INTO public.logs_navegacao VALUES (14, '5326646936', 'escadas_02', '/decanso_curto', NULL, false, '2026-03-12 18:37:47.893872');
INSERT INTO public.logs_navegacao VALUES (15, '5326646936', 'escadas_02', '/decanso_curto', NULL, false, '2026-03-12 18:45:47.74435');
INSERT INTO public.logs_navegacao VALUES (16, '5326646936', 'escadas_02', '/descanso', NULL, false, '2026-03-12 18:48:44.43242');


--
-- Data for Name: masmorra_cenas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.masmorra_cenas VALUES (1, 'cidadela_entrada', 'O Desfiladeiro de Old Road', 'Uma fenda enorme se abre no chão. Escadas de pedra precárias descem para a escuridão da Cidadela. O ar é frio e cheira a terra antiga.', 'nenhum', 'baixo');


--
-- Data for Name: monster_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.monster_templates VALUES (1, 'Goblin', 7, 15, 4, '1d6+2', 50);
INSERT INTO public.monster_templates VALUES (2, 'Orc', 15, 13, 5, '1d12+3', 100);
INSERT INTO public.monster_templates VALUES (3, 'Lobo', 11, 13, 4, '2d4+2', 50);
INSERT INTO public.monster_templates VALUES (4, 'Esqueleto', 13, 13, 4, '1d6+2', 50);
INSERT INTO public.monster_templates VALUES (5, 'Ogre', 59, 11, 6, '2d8+4', 450);
INSERT INTO public.monster_templates VALUES (6, 'Dragão Jovem', 136, 18, 10, '2d10+4', 2900);


--
-- Data for Name: regras_cache; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: turnos; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: aliados_e_npcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aliados_e_npcs_id_seq', 3, true);


--
-- Name: aventuras_catalogo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aventuras_catalogo_id_seq', 3, true);


--
-- Name: aventuras_inventario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aventuras_inventario_id_seq', 1, false);


--
-- Name: aventuras_paragrafos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aventuras_paragrafos_id_seq', 6, true);


--
-- Name: aventuras_progresso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aventuras_progresso_id_seq', 5, true);


--
-- Name: aventuras_stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aventuras_stats_id_seq', 1, false);


--
-- Name: campanhas_cenas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.campanhas_cenas_id_seq', 1, true);


--
-- Name: diario_thorak_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.diario_thorak_id_seq', 1, true);


--
-- Name: documentos_aventura_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documentos_aventura_id_seq', 3, true);


--
-- Name: encontros_salas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.encontros_salas_id_seq', 102, true);


--
-- Name: grimorio_cidadela_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grimorio_cidadela_id_seq', 8, true);


--
-- Name: itens_magicos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.itens_magicos_id_seq', 4, true);


--
-- Name: logs_navegacao_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logs_navegacao_id_seq', 16, true);


--
-- Name: masmorra_cenas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.masmorra_cenas_id_seq', 1, true);


--
-- Name: monster_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.monster_templates_id_seq', 6, true);


--
-- Name: aliados_e_npcs aliados_e_npcs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aliados_e_npcs
    ADD CONSTRAINT aliados_e_npcs_pkey PRIMARY KEY (id);


--
-- Name: aventura_cidadela aventura_cidadela_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventura_cidadela
    ADD CONSTRAINT aventura_cidadela_pkey PRIMARY KEY (cod_sala);


--
-- Name: aventuras_catalogo aventuras_catalogo_nome_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_catalogo
    ADD CONSTRAINT aventuras_catalogo_nome_key UNIQUE (nome);


--
-- Name: aventuras_catalogo aventuras_catalogo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_catalogo
    ADD CONSTRAINT aventuras_catalogo_pkey PRIMARY KEY (id);


--
-- Name: aventuras_inventario aventuras_inventario_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_inventario
    ADD CONSTRAINT aventuras_inventario_pkey PRIMARY KEY (id);


--
-- Name: aventuras_paragrafos aventuras_paragrafos_aventura_nome_numero_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_paragrafos
    ADD CONSTRAINT aventuras_paragrafos_aventura_nome_numero_key UNIQUE (aventura_nome, numero);


--
-- Name: aventuras_paragrafos aventuras_paragrafos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_paragrafos
    ADD CONSTRAINT aventuras_paragrafos_pkey PRIMARY KEY (id);


--
-- Name: aventuras_progresso aventuras_progresso_jogador_id_aventura_nome_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_progresso
    ADD CONSTRAINT aventuras_progresso_jogador_id_aventura_nome_key UNIQUE (jogador_id, aventura_nome);


--
-- Name: aventuras_progresso aventuras_progresso_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_progresso
    ADD CONSTRAINT aventuras_progresso_pkey PRIMARY KEY (id);


--
-- Name: aventuras_stats aventuras_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_stats
    ADD CONSTRAINT aventuras_stats_pkey PRIMARY KEY (id);


--
-- Name: bestiario_cidadela bestiario_cidadela_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bestiario_cidadela
    ADD CONSTRAINT bestiario_cidadela_pkey PRIMARY KEY (nome);


--
-- Name: campanhas_cenas campanhas_cenas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campanhas_cenas
    ADD CONSTRAINT campanhas_cenas_pkey PRIMARY KEY (id);


--
-- Name: campanhas campanhas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.campanhas
    ADD CONSTRAINT campanhas_pkey PRIMARY KEY (grupo_id);


--
-- Name: cenas cenas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cenas
    ADD CONSTRAINT cenas_pkey PRIMARY KEY (cod_sala);


--
-- Name: criacao_ficha criacao_ficha_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.criacao_ficha
    ADD CONSTRAINT criacao_ficha_pkey PRIMARY KEY (telefone);


--
-- Name: diario_thorak diario_thorak_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diario_thorak
    ADD CONSTRAINT diario_thorak_pkey PRIMARY KEY (id);


--
-- Name: documentos_aventura documentos_aventura_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_aventura
    ADD CONSTRAINT documentos_aventura_pkey PRIMARY KEY (id);


--
-- Name: encontros_salas encontros_salas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.encontros_salas
    ADD CONSTRAINT encontros_salas_pkey PRIMARY KEY (id);


--
-- Name: grimorio_cidadela grimorio_cidadela_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grimorio_cidadela
    ADD CONSTRAINT grimorio_cidadela_pkey PRIMARY KEY (id);


--
-- Name: itens_magicos itens_magicos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.itens_magicos
    ADD CONSTRAINT itens_magicos_pkey PRIMARY KEY (id);


--
-- Name: jogadores jogadores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jogadores
    ADD CONSTRAINT jogadores_pkey PRIMARY KEY (telefone);


--
-- Name: logs_navegacao logs_navegacao_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs_navegacao
    ADD CONSTRAINT logs_navegacao_pkey PRIMARY KEY (id);


--
-- Name: masmorra_cenas masmorra_cenas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.masmorra_cenas
    ADD CONSTRAINT masmorra_cenas_pkey PRIMARY KEY (id);


--
-- Name: masmorra_cenas masmorra_cenas_sala_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.masmorra_cenas
    ADD CONSTRAINT masmorra_cenas_sala_id_key UNIQUE (sala_id);


--
-- Name: monster_templates monster_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monster_templates
    ADD CONSTRAINT monster_templates_pkey PRIMARY KEY (id);


--
-- Name: regras_cache regras_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.regras_cache
    ADD CONSTRAINT regras_cache_pkey PRIMARY KEY (nome);


--
-- Name: turnos turnos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turnos
    ADD CONSTRAINT turnos_pkey PRIMARY KEY (grupo_id);


--
-- Name: idx_aventuras_nome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_aventuras_nome ON public.aventuras_catalogo USING btree (nome);


--
-- Name: idx_cenas_aventura; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cenas_aventura ON public.campanhas_cenas USING btree (aventura_ref, cena_id);


--
-- Name: idx_criacao_telefone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_criacao_telefone ON public.criacao_ficha USING btree (telefone);


--
-- Name: idx_paragrafos_aventura_numero; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_paragrafos_aventura_numero ON public.aventuras_paragrafos USING btree (aventura_nome, numero);


--
-- Name: idx_progresso_jogador; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_progresso_jogador ON public.aventuras_progresso USING btree (jogador_id);


--
-- Name: aventuras_inventario aventuras_inventario_progresso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_inventario
    ADD CONSTRAINT aventuras_inventario_progresso_id_fkey FOREIGN KEY (progresso_id) REFERENCES public.aventuras_progresso(id) ON DELETE CASCADE;


--
-- Name: aventuras_paragrafos aventuras_paragrafos_aventura_nome_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_paragrafos
    ADD CONSTRAINT aventuras_paragrafos_aventura_nome_fkey FOREIGN KEY (aventura_nome) REFERENCES public.aventuras_catalogo(nome) ON DELETE CASCADE;


--
-- Name: aventuras_progresso aventuras_progresso_aventura_nome_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_progresso
    ADD CONSTRAINT aventuras_progresso_aventura_nome_fkey FOREIGN KEY (aventura_nome) REFERENCES public.aventuras_catalogo(nome) ON DELETE CASCADE;


--
-- Name: aventuras_stats aventuras_stats_aventura_nome_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aventuras_stats
    ADD CONSTRAINT aventuras_stats_aventura_nome_fkey FOREIGN KEY (aventura_nome) REFERENCES public.aventuras_catalogo(nome) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA public TO rpg;


--
-- PostgreSQL database dump complete
--

